﻿<HTML>
<head>
<title>apache log search form<?if ($searchterm) {echo ": $searchterm";}?></title>
<style type="text/css">
    body {
        font-family: sans-serif;
        font-size: 14pt;
        background-color: #aaaaaa;
        text-align: center;
    }
    .results {
        padding: 10px;
        width: 70%;
        text-align: left;
        border-top: 1px solid white;
        border-left: 1px solid white;
        border-bottom: 1px solid black;
        border-right: 1px solid black;
        background-color: #dddddd;
        font-family: sans-serif;
        font-size: 8pt;
        }
    .send {
        padding: 0px;
        margin: 0px;
        vertical-align: middle;
        border: 1px solid #888888;
        font-size: 8pt;
        font-family: sans-serif;
        }
</style>
</head>
<body>
<?php
global $searchterm;


// only show results if a search term is
// passed through the script.

if ($searchterm) {

?>
<b>Searching for:</b>

<?
echo "$searchterm<br><br>";
?>
<div class="results">
<?





// <meta http-equiv="refresh" content="60;/scripts/search.php?searchterm=<?=$searchterm

// first, tell it which logfile to access...
$filename="/var/log/apache/staticred-access.log";
$filename2="/var/log/apache/staticred-access.log.1";
// now, put the contents of the file into
// an array

$entry = array();
$entry = file($filename2) or die("Cannot open file");
$fillval = count($entry);
$entry2 = array_fill(0, $fillval, "");
$entry2 = file($filename) or die("Cannot open file");

// array_merge($entry,$entry1);
$entry = array_merge($entry,$entry2);
$i=0;

// this will go through each line in $entry
// and place it into a variable, $si.  Since
// record entries in apache logs are delimited
// by a new line, the foreach function is a
// nice, easy solution to analysis.

foreach ($entry as $si) {

// first, remove references to images, css files,
// and my own IP, as well as this script.

if (ereg($searchterm,$si) & !ereg(".css",$si) & !ereg(".jpg",$si) & !ereg("search.php",$si) & !ereg("ar.ed.shawcable.net",$si)) {

// now, move each line into an array, with
// each value delimited by a space.  This
// isn't a perfect method, but it's the best
// we have.
        $lineval = explode(" ",$si);

// Now, display the inf    vertical-align: middle;ormation we want to
// be shown to the browser; in this case,
// the site that requested the page, the
// URL they requested, the site they were
// referred from, and the date/time it
// was requested.  Because we've already
// split this data into an array, it's easy
// to display.

          echo "<b>Site:</b> <a href=\"/scripts/search.php?searchterm=$lineval[0]\">$lineval[0]</a> (click to show path through site)<br>";
          echo "<b>URL:</b> <a href=\"/scripts/search.php?searchterm=$lineval[6]\">$lineval[6]</a> (click to see what other sites have hit this URL)<br>";
          
// let's strip the double-quotes out of the
// string.

          $lineval[10] = ereg_replace(chr(34),"",$lineval[10]);

// if there's no referer, then show nothing.  
// if there is, show it and link to it.

          if ($lineval[10] != "-") {
              echo "<b>Referer:</b> <a href=\"$lineval[10]\">$lineval[10]</a> &#187; <a href=\"/scripts/search.php?searchterm=$lineval[10]\">search this term</a><br>";
          }
          else {
          echo "<b>Direct Request</b><br>";
          }
          echo "<b>Browser:</b> $lineval[11] $lineval[12] $lineval[13] $lineval[14] $lineval[15] $lineval[16] $lineval[17]<br/>";
          echo "<b>Date:</b> $lineval[3]$lineval[4]";
          echo "<hr>";
        $i++;
        }
    }
// how many entries have we processed?

?>
<?
echo "<br><br>Number of entries: $i &#187; ";
}

// and finally, display the form.
?>

<form action="/scripts/search.php">
Search for term: <input type="text" name="searchterm" class="send"> <input type="submit" class="send" value=" &#187; ">
</form>
</body>
</html>
